-- Test function call.

select default.ip_to_long('10.0.23.43') from default.dual;
select default.long_to_ip(167778091) from default.dual;
