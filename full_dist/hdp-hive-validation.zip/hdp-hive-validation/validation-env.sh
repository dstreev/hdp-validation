# HS2 Location
HS2_HOST=localhost
HS2_PORT=10000

# Data Generator Options
# ============================
# 5 nodes or less
DG_MAPPERS=5
DG_RECORDS=100000000

# 10 nodes or less
#DG_MAPPERS=20
#DG_RECORDS=500000000

# Greater than 10
#DG_MAPPERS=50
#DG_RECORDS=1000000000
# ============================
