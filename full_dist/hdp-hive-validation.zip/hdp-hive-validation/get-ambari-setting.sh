#!/bin/bash

. $HOME/.hdp-validation-env.sh
