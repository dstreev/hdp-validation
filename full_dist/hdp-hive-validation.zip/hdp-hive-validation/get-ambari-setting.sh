#!/bin/bash

. $HOME/.hdp-validation-env.sh

curl -G --user $AMBARI_USER:$AMBARI_PASSWORD http://$AMBARI_HOST:$AMBARI_PORT/api/v1/clusters/$CLUSTER?fields=Clusters/desired_configs